import json
import sys
import cv2
import requests
from PyQt5 import QtWidgets, QtGui, QtCore, uic
from utils import get_access_token, vehicle_detect, vehicle_type_recognize

# Replace with actual paths
IMAGE_PATH = '../data/1.jfif'
VIDEO_PATH = '../data/vd.mp4'

class VideoProcessor(QtCore.QThread):
    frame_processed = QtCore.pyqtSignal(QtGui.QPixmap, str)

    def __init__(self, video_path, access_token, parent=None):
        super(VideoProcessor, self).__init__(parent)
        self.video_path = video_path
        self.access_token = access_token

    def run(self):
        cap = cv2.VideoCapture(self.video_path)
        if not cap.isOpened():
            print(f"Error: Failed to open video file: {self.video_path}")
            return

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Vehicle detection
            detect_result = vehicle_detect(frame, self.access_token, top_num=5)
            if detect_result.get("error_code"):
                info_text = f"Error: {detect_result['error_msg']}"
            else:
                info_text = self.parse_detect_result(detect_result, frame)

            # Convert video frame to QPixmap
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            height, width, channel = frame_rgb.shape
            bytes_per_line = 3 * width
            q_img = QtGui.QImage(frame_rgb.data, width, height, bytes_per_line, QtGui.QImage.Format_RGB888)
            pixmap = QtGui.QPixmap.fromImage(q_img)

            # Emit signal to update UI
            self.frame_processed.emit(pixmap, info_text)

        cap.release()

    def parse_detect_result(self, detect_result, frame):
        info_text = "<b>车辆总数:</b> {}<br><ol>".format(detect_result['vehicle_num']) if 'vehicle_num' in detect_result else ""
        if 'vehicle_num' in detect_result:
            height, width, _ = frame.shape
            for vehicle in detect_result['vehicle_info']:
                # Extract vehicle location
                x, y, w, h = vehicle['location'].values()
                vehicle_info_text = ""
                # Boundary check
                if x < 0 or y < 0 or x + w > width or y + h > height:
                    vehicle_info_text = "Error: Invalid crop region"
                else:
                    vehicle_crop = frame[y:y + h, x:x + w]

                    # Check if cropped image is empty
                    if vehicle_crop is None or vehicle_crop.size == 0:
                        vehicle_info_text = "Error: Empty image provided for vehicle type recognition"
                    else:
                        # Vehicle type recognition
                        try:
                            vehicle_type_info = vehicle_type_recognize(vehicle_crop, self.access_token)
                            if vehicle_type_info.get("error_code"):
                                vehicle_info_text = f"Error: {vehicle_type_info['error_msg']}"
                            else:
                                vehicle_info_text = json.dumps(vehicle_type_info, ensure_ascii=False, indent=2).replace("\n", "<br>")
                        except Exception as e:
                            vehicle_info_text = f"Error: {str(e)}"

                info_text += "<li><b>{}</b>: {}</li>".format(vehicle['type'], vehicle_info_text)

                # Draw rectangle on the video frame
                cv2.rectangle(frame, (y, x), (y + w, x + h), (0, 255, 0), 2)

        info_text += "</ol>"
        return info_text

class MainWindow(QtWidgets.QDialog):
    def __init__(self):
        super(MainWindow, self).__init__()
        uic.loadUi('mpage.ui', self)
        self.pushButton.clicked.connect(self.open_monitor_page)

        # Load image
        self.load_image()

    def load_image(self):
        # Load local image file and display on label_image
        pixmap = QtGui.QPixmap(IMAGE_PATH)
        self.label_image.setPixmap(pixmap)
        self.label_image.setScaledContents(True)

    def open_monitor_page(self):
        self.monitor_window = MonitorWindow()
        self.monitor_window.start_video_processing()
        self.monitor_window.show()
        self.close()

class MonitorWindow(QtWidgets.QDialog):
    def __init__(self):
        super(MonitorWindow, self).__init__()
        uic.loadUi('car.ui', self)
        self.video_processor = None

        # Add QScrollArea for label_info
        self.scroll_area = QtWidgets.QScrollArea(self)
        self.scroll_area.setGeometry(self.label_info.geometry())
        self.scroll_area.setWidgetResizable(True)

        self.scroll_content = QtWidgets.QWidget()
        self.scroll_layout = QtWidgets.QVBoxLayout(self.scroll_content)
        self.label_info.setAlignment(QtCore.Qt.AlignTop)
        self.scroll_layout.addWidget(self.label_info)
        self.scroll_area.setWidget(self.scroll_content)

    def start_video_processing(self):
        access_token = get_access_token()
        if not access_token:
            print("Error: Failed to obtain access token")
            return

        self.video_processor = VideoProcessor(VIDEO_PATH, access_token)
        self.video_processor.frame_processed.connect(self.update_frame)
        self.video_processor.start()

    def update_frame(self, pixmap, info_text):
        self.label_video.setPixmap(pixmap)
        self.label_info.setText(info_text)
        self.label_info.setWordWrap(True)

    def closeEvent(self, event):
        if self.video_processor:
            self.video_processor.quit()
            self.video_processor.wait()
        event.accept()

def main():
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
