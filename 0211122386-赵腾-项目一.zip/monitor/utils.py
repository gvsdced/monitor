import cv2
import requests
import base64

# 百度智能云API Key和Secret Key
API_KEY = 'VYAv5DFjl1udGRHPhdH7WH0z'
SECRET_KEY = 'nkj1chsIqdHa2XJumZGKRFwDMgKkzPi2'

# 获取Access Token
def get_access_token():
    url = 'https://aip.baidubce.com/oauth/2.0/token'
    params = {
        'grant_type': 'client_credentials',
        'client_id': API_KEY,
        'client_secret': SECRET_KEY
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # 检查HTTP请求的状态码

        result = response.json()
        if 'access_token' in result:
            return result['access_token']
        else:
            print(f"Error: Failed to obtain access token, response: {result}")
            return None
    except requests.RequestException as e:
        print(f"Request Error: {str(e)}")
        return None

# 车辆检测
def vehicle_detect(image, access_token, top_num=5):
    if image is None or image.size == 0:
        raise ValueError("Empty image provided for vehicle detection")

    detect_url = f'https://aip.baidubce.com/rest/2.0/image-classify/v1/vehicle_detect?access_token={access_token}'
    _, img_encoded = cv2.imencode('.jpg', image)  # 将图像编码为JPEG格式
    img_base64 = base64.b64encode(img_encoded).decode()  # 将图像编码为base64字符串
    params = {
        'image': img_base64,
        'top_num': top_num
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(detect_url, data=params, headers=headers)  # 调用车辆检测API
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Error in vehicle_detect: {response.json()}")

# 车型识别
def vehicle_type_recognize(image, access_token, output_brand='true'):
    if image is None or image.size == 0:
        raise ValueError("Empty image provided for vehicle type recognition")

    type_url = f'https://aip.baidubce.com/rest/2.0/image-classify/v1/car?access_token={access_token}'
    _, img_encoded = cv2.imencode('.jpg', image)  # 将图像编码为JPEG格式
    img_base64 = base64.b64encode(img_encoded).decode()  # 将图像编码为base64字符串
    params = {
        'image': img_base64,
        'output_brand': output_brand
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(type_url, data=params, headers=headers)  # 调用车型识别API
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Error in vehicle_type_recognize: {response.json()}")
